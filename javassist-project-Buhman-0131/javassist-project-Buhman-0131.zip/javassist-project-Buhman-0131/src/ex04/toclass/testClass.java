package ex04.toclass;

public class testClass {
	public static void main(String args[])
	{
		int idA = 1;
		String nameA = "name";
		System.out.println("[TR] After calling a constructor: idA: " + idA + " nameA: " + nameA);
	}

}
