Javassist 3.24.1-GA
